<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mój kalendarz</title>
    <link rel="stylesheet" href="styl5.css">
</head>
<body>
    <div class="banery">
        <section id='banner1'>
            <img src="logo1.png" alt="Mój kalendarz">
        </section>
        <section id='banner2'>
            <h2>KALENDARZ</h2>
        </section>
    </div>
    <section id='blokGlowny'>
<?php
	$conn = new mysqli('localhost', 'root', '');
	if ($conn->connect_error) {
		die("Connection failed: " . $conn->connect_error);
	}

	$db = mysqli_select_db($conn, 'egzamin5');

	$query = mysqli_query($conn, 'SELECT * FROM zadania');

	while($zadanie = mysqli_fetch_array($query)) {
		// for ($i = 0; $i < mysqli_num_fields($query); $i++) {
		// 	echo "$osoba ";
		// }
		//echo "{$osoba['id']} - {$osoba['imiona']} {$osoba['nazwiska']} - {$osoba['ogloszenia']}";
        echo "
        <section class='daneDni'>
            <h5>{$zadanie['dataZadania']}</h5>
            <p>{$zadanie['wpis']}</p>
        </section>";
	}
	
?>
    </section>
    <section id='stopka'>
        Dodaj wpis:<input type="text"> 
        <button id='btn'>DODAJ</button>
        <P>Stronę wykonał: 00000000000</P>
    </section>
</body>
</html>