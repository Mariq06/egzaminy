<?php
$conn = mysqli_connect('localhost', 'root', '', 'wedkarstwo');
if ($conn == true){
    echo('udało się <br>');
}else{
    echo('błąd, nie można połączyć z bazą <br>');
}
$query1 = mysqli_query($conn, 'insert into zawody_wedkarskie values ("", 0, '.$_POST["lowisko"].', "'.$_POST["data"].'", "'.$_POST["sedzia"].'")');
//echo('insert into zawody_wedkarskie values ("", 2, '.$_POST["lowisko"].', "'.$_POST["data"].'", "'.$_POST["sedzia"].'")');

mysqli_close($conn);
?>