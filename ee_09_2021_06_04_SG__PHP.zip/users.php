<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Panel administratora</title>
  <link rel="stylesheet" href="styl4.css">
</head>

<body>

  <header>
    <h3>Portal Społecznościowy - panel administratora</h3>
  </header>

  <main>

    <div class="left">
      <h4>Użytkownicy</h4>
      <?php
      $conn = mysqli_connect('localhost', 'root', '', 'dane4');
      $query1 = mysqli_query($conn, 'select id, imie, nazwisko, rok_urodzenia, zdjecie from osoby limit 30;');
      $num_of_rows = mysqli_num_rows($query1);

      for ($i = 0; $i < $num_of_rows; $i++) {
        $arrayUsers = mysqli_fetch_array($query1);
        $wiek = date('Y') - $arrayUsers['rok_urodzenia'];
        echo "
        <table>
        <tr>
          <td>".$arrayUsers['id'].".</td>
          <td>".$arrayUsers['imie']."</td>
          <td>".$arrayUsers['nazwisko'].",</td>
          <td>".$wiek." lat</td>
        </tr>
      </table>";
      }

      mysqli_close($conn);
      ?>
      <a href="settings.html">Inne ustawienia</a>
    </div>

    <div class="right">
      <h2>Podaj usera:</h2>
      <form action="" method=post>
        <input type="number" name="id">
        <button class="btn">Zobacz</button>
      </form>

      <hr>
      <div class="details">
        <?php
        $conn = mysqli_connect('localhost', 'root', '', 'dane4');
        $query2 = mysqli_query($conn, 'select imie, nazwisko, rok_urodzenia, opis, zdjecie, hobby.nazwa from osoby join hobby on osoby.hobby_id = hobby.id where osoby.id='.$_POST["id"].';');
        $arrayQuery2 = mysqli_fetch_array($query2);

        echo '<h2>'.$_POST['id'].'. '.$arrayQuery2['imie'].' '.$arrayQuery2['nazwisko'].'</h2><br>
        <img src="'.$arrayQuery2["zdjecie"].'" alt="'.$_POST["id"].'"><br>
        <p>Rok urodzenia: '.$arrayQuery2["rok_urodzenia"].'</p>
        <p>Opis: '.$arrayQuery2["opis"].'</p>
        <p>Hobby: '.$arrayQuery2["nazwa"].'</p>';

        mysqli_close($conn);
        ?>
      </div>
    </div>
  </main>

  <footer>
    Strone wykonał: 0000000000
  </footer>
</body>

</html>