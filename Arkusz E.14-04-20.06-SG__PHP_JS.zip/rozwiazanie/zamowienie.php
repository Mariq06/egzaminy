<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="styl.css">
</head>
<body>
    <header>
        <h1>Ozdoby - sklep</h1>
    </header>
    <main>
        <nav id="left">
            <h2>OZDOBY</h2>
            <a href="galeria.html">Galeria</a><br>
            <a href="zamowienie.php">Zamówienie</a><br>
        </nav>
        <nav id="middle">
            <p>Dodaj użytkownika</p>
            <form action="" method="post">
                Imię: <input type="text" name="imie"><br>
                Nazwisko: <input type="text" name="nazwisko"><br>
                e-mail: <input type="email" name="email"><br>
                <button name="send">WYŚLIJ</button><br>
            </form>
        </nav>
        <nav id="right">
            <img src="animacja.gif">
        </nav>
    </main>
    <footer>
        <h3>Autor strony: 00000000000</h3>
    </footer>
</body>
</html>
<?php
    $conn = mysqli_connect('localhost', 'root', '', 'sklep');
    $query = mysqli_query($conn, 'insert into zamowienia (imie, nazwisko, adres_email) values ("'.$_POST["imie"].'", "'.$_POST["nazwisko"].'", "'.$_POST["email"].'")');


    mysqli_close($conn);
?>