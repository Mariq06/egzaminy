const choinka = document.getElementById("choinka");
const mikolaj = document.getElementById("mikolaj");
const renifer = document.getElementById("renifer");
let wynikSkryptu = document.getElementById("wynikSkryptu");

function wybor(event){
    if(event.target === choinka){
        wynikSkryptu.innerHTML = 'Wybrałeś choinkę. Cena 10 zł'
    }
    else if(event.target === mikolaj){
        wynikSkryptu.innerHTML = 'Wybrałeś mikołaja. Cena 12 zł'
    }
    else{
        wynikSkryptu.innerHTML = 'Wybrałeś renifera. Cena 8 zł'
    }
}

choinka.addEventListener('click', wybor)
mikolaj.addEventListener('click', wybor)
renifer.addEventListener('click', wybor)