<?php
try {
    $conn = mysqli_connect('localhost', 'root', '', 'wedkowanie');
} catch(Exception $e) {
    echo 'błąd ', $e->getMessage();
    exit(1);
}
?>
<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Wędkowanie</title>
    <link rel="stylesheet" href="styl_1.css">
</head>
<body>
    <header>
        <h1>Portal dla wędkarzy</h1>
    </header>
    <div class="bloki">
        <section>
            <article id='blokLewy1'>
                <h3>Ryby zamieszkujące rzeki</h3>
                <ol>
<?php
$query3 = mysqli_query($conn, 'select Ryby.nazwa, Lowisko.akwen, Lowisko.wojewodztwo from Ryby join Lowisko on Ryby.id = Lowisko.Ryby_id where Lowisko.rodzaj = 3;');
for ($i = 0; $i<$query3->num_rows; $i++){
    $list = mysqli_fetch_array($query3);
    echo '<li>', $list[0], ' pływa w rzece ', $list[1], ', ', $list[2]; 
}
?>
                </ol>
            </article>
            <article id=''blokLewy2>
                <h3>Ryby drapieżne naszych wód</h3>
                <table>
                    <tr>
                        <td>L.p</td>
                        <td>Gatunek</td>
                        <td>Występowanie</td>
                    </tr>
<?php
$query1 = mysqli_query($conn, 'select id, nazwa, wystepowanie from Ryby where styl_zycia = 1');
//var_dump($query1);
//$result = mysqli_fetch_row($query1);
//$table = mysqli_fetch_array($query1);
//var_dump($table);
//echo'<br>';
//var_dump($result);
//echo $result[1];
for ($i = 0; $i<$query1->num_rows; $i++){
    $table = mysqli_fetch_array($query1);
    echo '
    <tr>
        <td>', $table[0], '</td>
        <td>', $table[1], '</td>
        <td>', $table[2], '</td>
    </tr>';
}
mysqli_close($conn);
?>
                </table>
            </article>
        </section>
        <aside>
            <img src="ryba1.jpg" alt="Sum">
            <a href="kwerendy.txt">Pobierz kwerendy</a>
        </aside>
    </div>
    <footer>
        <p>Stronę wykonał: 00000000000</p>
    </footer>

</body>
</html>