<?php
$conn = mysqli_connect('localhost', 'root', '', 'dane3');

$zapytanie4 = 'delete from produkty where id='.$_POST['id'];
$wynikZapytania4 = mysqli_query($conn, $zapytanie4);

function KartyFilmow($zapytanie1, $conn){
  $wynikZapytania1 = mysqli_query($conn, $zapytanie1);
  $iloscWierszy = mysqli_num_rows($wynikZapytania1);
  $i = 0;
  while($i<$iloscWierszy){
    $array1 = mysqli_fetch_array($wynikZapytania1);
    echo "
      <div class='karta'>
      <h4>".$array1['id'].". ".$array1['nazwa']."</h4>
      <img src='".$array1['zdjecie']."' alt='film'>
      <p>".$array1['opis']."</p>
      </div>";
      $i++;
  }
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Video On Demand</title>
  <link rel="stylesheet" href="styl3.css">
</head>

<body>
  <header>
    <section id='baner1'>
      <h1>Internetowa wypożyczalnia filmów</h1>
    </section>
    <section id='baner2'>
      <table>
        <tr>
          <td>Kryminał</td>
          <td>Horror</td>
          <td>Przygodowy</td>
        </tr>
        <tr>
          <td>20</td>
          <td>30</td>
          <td>20</td>
        </tr>
      </table>
    </section>
  </header>

  <nav id='polecamy'>
    <h3>Polecamy</h3>
    <section class='skrypt'>
    <?php
        $zapytanie1 = "select id, nazwa, opis, zdjecie from produkty where id in(18, 22, 23, 25)";
        KartyFilmow($zapytanie1, $conn);
        
      ?>
    </section>
  </nav>

  <nav id="fantastyczne">
    <h3>Filmy fantastyczne</h3>
    <section class='skrypt'>
      <?php
          $zapytanie1 = "select id, nazwa, opis, zdjecie from produkty where Rodzaje_id = 12";
          KartyFilmow($zapytanie1, $conn);
        ?>
    </section>
</nav>

  <footer>
    <form action="" method="post">
      Usuń film o nr: <input type="number" name="id" required>
      <button>Usuń film</button>
    </form>
    <p>Stronę wykonał: 00000000000</p>
  </footer>
</body>

</html>
<?php
mysqli_close($conn);
?>